document.addEventListener('DOMContentLoaded', () => {
    const contactForm = document.getElementById('contactForm');
    const errorMessage = document.getElementById('errorMessage');
    const unblockButton = document.getElementById('unblockButton');
    const ipToUnblock = document.getElementById('ipToUnblock');
    const blockedIpsList = document.getElementById('blockedIpsList');
    const totalRequestsSpan = document.getElementById('totalRequests');

    // Contact Form Submission
    contactForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        errorMessage.textContent = '';

        const name = document.getElementById('name').value;
        const email = document.getElementById('email').value;
        const message = document.getElementById('message').value;

        try {
            const response = await fetch('/', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ name, email, message })
            });

            const result = await response.json();

            if (result.status === 'success') {
                alert('Message sent successfully!');
                contactForm.reset();
            } else {
                errorMessage.textContent = result.message;
            }
        } catch (error) {
            errorMessage.textContent = 'An error occurred. Please try again.';
        }
    });

    // IP Unblock Functionality
    unblockButton.addEventListener('click', async () => {
        const ipAddress = ipToUnblock.value.trim();

        if (!ipAddress) {
            alert('Please enter an IP address');
            return;
        }

        try {
            const response = await fetch('/unblock/', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ ip_address: ipAddress })
            });

            const result = await response.json();

            if (result.status === 'success') {
                alert(`IP ${ipAddress} unblocked successfully`);
                ipToUnblock.value = '';
                fetchBlockedIPs();
            } else {
                alert(result.message);
            }
        } catch (error) {
            alert('An error occurred while unblocking the IP.');
        }
    });

    // Fetch Blocked IPs
    async function fetchBlockedIPs() {
        try {
            const response = await fetch('/unblock/');
            const data = await response.text();
            
            // This is a simplified placeholder
            blockedIpsList.innerHTML = 'Blocked IPs will be displayed here';
        } catch (error) {
            console.error('Error fetching blocked IPs:', error);
            blockedIpsList.innerHTML = 'Unable to fetch blocked IPs';
        }
    }

    // Fetch total requests on page load
    async function fetchTotalRequests() {
        try {
            const response = await fetch('/unblock/');
            const data = await response.text();
            
            // Use a regex or DOM parsing to extract total requests
            const totalRequestsMatch = data.match(/Total Requests: (\d+)/);
            if (totalRequestsMatch) {
                totalRequestsSpan.textContent = totalRequestsMatch[1];
            }
        } catch (error) {
            console.error('Error fetching total requests:', error);
            totalRequestsSpan.textContent = 'N/A';
        }
    }

    // Initial calls
    fetchBlockedIPs();
    fetchTotalRequests();
});