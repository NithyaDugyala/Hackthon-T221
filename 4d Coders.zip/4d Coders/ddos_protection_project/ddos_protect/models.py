from django.db import models
from django.utils import timezone

class IPRequest(models.Model):
    """
    Model to track IP request counts and block status
    """
    ip_address = models.GenericIPAddressField(unique=True)
    request_count = models.IntegerField(default=0)
    is_blocked = models.BooleanField(default=False)
    first_request = models.DateTimeField(auto_now_add=True)
    last_request = models.DateTimeField(auto_now=True)

    def _str_(self):
        return f"{self.ip_address} - Requests: {self.request_count}"

class ContactMessage(models.Model):
    """
    Model to store contact form submissions
    """
    name = models.CharField(max_length=100)
    email = models.EmailField()
    message = models.TextField()
    created_at = models.DateTimeField(auto_now_add=True)

    def _str_(self):
        return f"Message from {self.name} at {self.created_at}"