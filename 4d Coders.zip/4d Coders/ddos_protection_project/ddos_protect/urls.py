from django.contrib import admin
from django.urls import path
from . import views

urlpatterns = [
    path('', views.contact_view, name='contact'),
    path('unblock/', views.unblock_ip, name='unblock_ip'),
]