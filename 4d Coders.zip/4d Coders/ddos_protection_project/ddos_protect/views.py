from django.shortcuts import render, redirect
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
from django.views.decorators.http import require_http_methods
from django.utils import timezone
from ipware import get_client_ip
from datetime import timedelta
from .models import IPRequest, ContactMessage
import json

# Configuration for DDoS protection
MAX_REQUESTS_THRESHOLD = 10  # Max requests before blocking
BLOCK_DURATION_HOURS = 24  # Hours to block an IP

def get_client_ip_address(request):
    """
    Get client IP address, handling proxy scenarios
    """
    client_ip, is_routable = get_client_ip(request)
    return client_ip if is_routable else '127.0.0.1'

def track_ip_request(ip_address):
    """
    Track and manage IP request counts
    """
    # Clean up old request records
    time_threshold = timezone.now() - timedelta(hours=BLOCK_DURATION_HOURS)
    
    # Get or create IP request record
    ip_record, created = IPRequest.objects.get_or_create(
        ip_address=ip_address,
        defaults={'request_count': 1}
    )
    
    # Check if record is old and reset if needed
    if not created and ip_record.first_request < time_threshold:
        ip_record.request_count = 1
        ip_record.first_request = timezone.now()
        ip_record.is_blocked = False
    
    # Increment request count
    ip_record.request_count += 1
    
    # Block if threshold exceeded
    if ip_record.request_count > MAX_REQUESTS_THRESHOLD:
        ip_record.is_blocked = True
    
    ip_record.save()
    return ip_record

@csrf_exempt
@require_http_methods(["GET", "POST"])
def contact_view(request):
    """
    Handle contact form submissions with DDoS protection
    """
    # Get client IP
    client_ip = get_client_ip_address(request)
    
    # Check IP status
    ip_record = track_ip_request(client_ip)
    
    # If blocked, return error
    if ip_record.is_blocked:
        return JsonResponse({
            'status': 'error', 
            'message': 'Too many requests. IP temporarily blocked.'
        }, status=429)
    
    # Handle POST request (form submission)
    if request.method == 'POST':
        try:
            # Parse JSON data
            data = json.loads(request.body)
            
            # Create contact message
            ContactMessage.objects.create(
                name=data.get('name', ''),
                email=data.get('email', ''),
                message=data.get('message', '')
            )
            
            return JsonResponse({
                'status': 'success', 
                'message': 'Message sent successfully!'
            })
        except Exception as e:
            return JsonResponse({
                'status': 'error', 
                'message': str(e)
            }, status=400)
    
    # Render contact page for GET request
    total_requests = ContactMessage.objects.count()
    blocked_ips = IPRequest.objects.filter(is_blocked=True)
    
    return render(request, 'index.html', {
        'max_requests': MAX_REQUESTS_THRESHOLD,
        'total_requests': total_requests,
        'blocked_ips': blocked_ips
    })

def unblock_ip(request):
    """
    Manually unblock an IP address
    """
    if request.method == 'POST':
        try:
            data = json.loads(request.body)
            ip_to_unblock = data.get('ip_address')
            
            if ip_to_unblock:
                ip_record = IPRequest.objects.filter(ip_address=ip_to_unblock).first()
                if ip_record:
                    ip_record.is_blocked = False
                    ip_record.request_count = 0
                    ip_record.save()
                    return JsonResponse({
                        'status': 'success', 
                        'message': f'IP {ip_to_unblock} unblocked'
                    })
                else:
                    return JsonResponse({
                        'status': 'error', 
                        'message': 'IP not found'
                    }, status=404)
        except Exception as e:
            return JsonResponse({
                'status': 'error', 
                'message': str(e)
            }, status=400)
    
    # If not a POST request, just return the context for rendering
    total_requests = ContactMessage.objects.count()
    blocked_ips = IPRequest.objects.filter(is_blocked=True)
    
    return render(request, 'index.html', {
        'total_requests': total_requests,
        'blocked_ips': blocked_ips
    })