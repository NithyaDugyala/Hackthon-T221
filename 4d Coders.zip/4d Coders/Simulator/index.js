// DDoS Attack Simulator

class DDOSSimulator {
    constructor() {
        // Configuration
        this.MAX_REQUESTS_PER_IP = 5;  // Max requests before blocking
        this.BLOCK_DURATION = 5 * 60 * 1000;  // 5 minutes block time

        // State tracking
        this.ipRequestCounts = {};
        this.blockedIPs = new Set();
        this.totalRequests = 0;
        this.ddosAttempts = 0;

        // DOM Elements
        this.form = document.getElementById('contact-form');
        this.ipInput = document.getElementById('user-ip');
        this.nameInput = document.getElementById('name');
        this.emailInput = document.getElementById('email');
        this.messageInput = document.getElementById('message');
        this.errorModal = document.getElementById('error-modal');
        this.closeModalBtn = document.querySelector('.close-btn');
        this.clearBlockedIpsBtn = document.getElementById('clear-blocked-ips');
        this.blockedIpsList = document.getElementById('blocked-ips-list');

        // Stat Elements
        this.totalRequestsStat = document.getElementById('total-requests');
        this.blockedIpsStat = document.getElementById('blocked-ips');
        this.ddosAttemptsStat = document.getElementById('ddos-attempts');

        // Bind event listeners
        this.bindEvents();
    }

    bindEvents() {
        this.form.addEventListener('submit', (e) => this.handleSubmit(e));
        this.closeModalBtn.addEventListener('click', () => this.closeErrorModal());
        this.clearBlockedIpsBtn.addEventListener('click', () => this.clearBlockedIPs());
    }

    handleSubmit(e) {
        e.preventDefault();

        const ip = this.ipInput.value.trim();
        
        // Validate IP (basic format check)
        if (!this.isValidIP(ip)) {
            alert('Please enter a valid IP address');
            return;
        }

        // Check if IP is blocked
        if (this.isIPBlocked(ip)) {
            this.showErrorModal();
            this.incrementDDOSAttempts();
            return;
        }

        // Track and increment request count for this IP
        this.trackIPRequest(ip);

        // Reset form
        this.form.reset();
    }

    isValidIP(ip) {
        // Basic IP validation regex
        const ipRegex = /^(\d{1,3}\.){3}\d{1,3}$/;
        return ipRegex.test(ip) && 
            ip.split('.').every(part => parseInt(part) >= 0 && parseInt(part) <= 255);
    }

    trackIPRequest(ip) {
        // Initialize count if not exists
        if (!this.ipRequestCounts[ip]) {
            this.ipRequestCounts[ip] = 0;
        }

        // Increment request count
        this.ipRequestCounts[ip]++;
        this.totalRequests++;
        this.updateStats();

        // Check if IP exceeds max requests
        if (this.ipRequestCounts[ip] > this.MAX_REQUESTS_PER_IP) {
            this.blockIP(ip);
        }
    }

    blockIP(ip) {
        this.blockedIPs.add(ip);
        
        // Remove block after specified duration
        setTimeout(() => {
            this.unblockIP(ip);
        }, this.BLOCK_DURATION);

        this.updateBlockedIPsList();
        this.updateStats();
    }

    unblockIP(ip) {
        this.blockedIPs.delete(ip);
        delete this.ipRequestCounts[ip];
        this.updateBlockedIPsList();
        this.updateStats();
    }

    isIPBlocked(ip) {
        return this.blockedIPs.has(ip);
    }

    showErrorModal() {
        this.errorModal.style.display = 'flex';
    }

    closeErrorModal() {
        this.errorModal.style.display = 'none';
    }

    incrementDDOSAttempts() {
        this.ddosAttempts++;
        this.updateStats();
    }

    updateBlockedIPsList() {
        // Clear existing list
        this.blockedIpsList.innerHTML = '';

        // Populate with blocked IPs
        this.blockedIPs.forEach(ip => {
            const listItem = document.createElement('li');
            listItem.textContent = ip;
            this.blockedIpsList.appendChild(listItem);
        });
    }

    clearBlockedIPs() {
        // Clear all blocked IPs
        this.blockedIPs.clear();
        this.ipRequestCounts = {};
        this.updateBlockedIPsList();
        this.updateStats();
    }

    updateStats() {
        // Update stat displays
        this.totalRequestsStat.textContent = this.totalRequests;
        this.blockedIpsStat.textContent = this.blockedIPs.size;
        this.ddosAttemptsStat.textContent = this.ddosAttempts;
    }
}

// Initialize the DDoS Simulator when the page loads
document.addEventListener('DOMContentLoaded', () => {
    window.ddosSimulator = new DDOSSimulator();
});